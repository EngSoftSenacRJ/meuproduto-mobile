export interface Marca {
    id: number;
    nome: string;
    descricao: string;
    habilitado: boolean;
}
export interface retornoPesquisa {
    nome: string;
    
    habilitado: boolean;
}
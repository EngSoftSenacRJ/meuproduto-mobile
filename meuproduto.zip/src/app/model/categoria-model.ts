export interface Categoria {
    id: number;
    nome: string;
    descricao: string;
 }

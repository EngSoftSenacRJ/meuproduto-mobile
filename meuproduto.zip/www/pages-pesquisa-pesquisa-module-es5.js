function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-pesquisa-pesquisa-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/components/tabs/tabs.component.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/tabs/tabs.component.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsTabsTabsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-tabs>\n  <ion-tab-bar slot=\"bottom\">\n    \n    <ion-tab-button tab=\"login\" disabled>\n      <ion-icon name=\"person-circle\"></ion-icon>\n      <ion-label>Login</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button routerLink=\"/pesquisa\">\n      <ion-icon name=\"search-circle\"></ion-icon>\n      <ion-label>Pesquisar</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"about\" disabled>\n      <ion-icon name=\"information-circle\"></ion-icon>\n      <ion-label>Sobre</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pesquisa/pesquisa.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pesquisa/pesquisa.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesPesquisaPesquisaPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content [fullscreen]=\"true\" id=\"content\">\n  \n<div id=\"titulo\">\n  Consultar Produtos\n</div>\n  <div id=\"formulario\">\n  <!-- LISTA DE CATEGORIAS -->\n  <ion-item>\n    <ion-label>Categoria</ion-label>\n    <ion-select  [(ngModel)]=\"categoria\" ok-text=\"Ok\" cancel-text=\"Cancelar\">\n      \n      <ion-select-option \n        *ngFor=\"let categoria of categorias\" \n        [value]=\"categoria\">\n          {{categoria.nome}}\n        </ion-select-option>\n\n    </ion-select>\n\n  </ion-item>\n  \n\n  <!-- LISTA DE MARCAS -->\n  <ion-item>\n    <ion-label>Marca</ion-label>\n    <ion-select  [(ngModel)]=\"marca\" ok-text=\"Ok\" cancel-text=\"Cancelar\">\n      \n      <ion-select-option \n        *ngFor=\"let marca of marcas\" \n        [value]=\"marca\">\n          {{marca.nome}}\n        </ion-select-option>\n        \n    </ion-select>\n  </ion-item>\n\n\n  <ion-item>\n    <ion-label position=\"floating\">Produto</ion-label>\n    <ion-input [(ngModel)]=\"produtoPesquisado\"></ion-input>\n  </ion-item>\n\n\n  <ion-item>\n    <ion-label>Distancia(KM)</ion-label>\n    <ion-select [(ngModel)]=\"distancia\" ok-text=\"Ok\" cancel-text=\"Cancelar\">\n      <ion-select-option value=\"1\">1</ion-select-option>\n      <ion-select-option value=\"3\">3</ion-select-option>\n      <ion-select-option value=\"5\">5</ion-select-option>\n      <ion-select-option value=\"10\">10</ion-select-option>\n      <ion-select-option value=\"20\">20</ion-select-option>\n      <ion-select-option value=\"30\">50</ion-select-option>\n    </ion-select>\n\n  </ion-item>\n\n\n  <ion-item>\n    <ion-button (click)=\"pesquisar()\" id=\"btnPesquinsa\">\n      Pesquisar\n    </ion-button>\n  </ion-item>\n  \n</div>\n\n<app-tabs></app-tabs>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/components/tabs/tabs.component.scss":
  /*!*****************************************************!*\
    !*** ./src/app/components/tabs/tabs.component.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsTabsTabsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-tabs {\n  --ion-background-color:#ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy90YWJzL0M6XFxVc2Vyc1xcSHVkc29uLnJhbWFsaG9cXERlc2t0b3BcXGFuZHJlXFxtZXVwcm9kdXRvL3NyY1xcYXBwXFxjb21wb25lbnRzXFx0YWJzXFx0YWJzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb21wb25lbnRzL3RhYnMvdGFicy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDhCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL3RhYnMvdGFicy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10YWJze1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojZmZmZmZmO1xyXG59IiwiaW9uLXRhYnMge1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiNmZmZmZmY7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/components/tabs/tabs.component.ts":
  /*!***************************************************!*\
    !*** ./src/app/components/tabs/tabs.component.ts ***!
    \***************************************************/

  /*! exports provided: TabsComponent */

  /***/
  function srcAppComponentsTabsTabsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TabsComponent", function () {
      return TabsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var TabsComponent = /*#__PURE__*/function () {
      function TabsComponent() {
        _classCallCheck(this, TabsComponent);
      }

      _createClass(TabsComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return TabsComponent;
    }();

    TabsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tabs',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./tabs.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/components/tabs/tabs.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./tabs.component.scss */
      "./src/app/components/tabs/tabs.component.scss"))["default"]]
    })], TabsComponent);
    /***/
  },

  /***/
  "./src/app/pages/pesquisa/pesquisa-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/pesquisa/pesquisa-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: PesquisaPageRoutingModule */

  /***/
  function srcAppPagesPesquisaPesquisaRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PesquisaPageRoutingModule", function () {
      return PesquisaPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _pesquisa_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./pesquisa.page */
    "./src/app/pages/pesquisa/pesquisa.page.ts");

    var routes = [{
      path: '',
      component: _pesquisa_page__WEBPACK_IMPORTED_MODULE_3__["PesquisaPage"]
    }];

    var PesquisaPageRoutingModule = function PesquisaPageRoutingModule() {
      _classCallCheck(this, PesquisaPageRoutingModule);
    };

    PesquisaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], PesquisaPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/pesquisa/pesquisa.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/pesquisa/pesquisa.module.ts ***!
    \***************************************************/

  /*! exports provided: PesquisaPageModule */

  /***/
  function srcAppPagesPesquisaPesquisaModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PesquisaPageModule", function () {
      return PesquisaPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _components_tabs_tabs_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../components/tabs/tabs.component */
    "./src/app/components/tabs/tabs.component.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _pesquisa_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./pesquisa-routing.module */
    "./src/app/pages/pesquisa/pesquisa-routing.module.ts");
    /* harmony import */


    var _pesquisa_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./pesquisa.page */
    "./src/app/pages/pesquisa/pesquisa.page.ts");
    /* harmony import */


    var _modal_resultado_pesquisa_resultado_pesquisa_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../modal/resultado-pesquisa/resultado-pesquisa.page */
    "./src/app/pages/modal/resultado-pesquisa/resultado-pesquisa.page.ts");

    var PesquisaPageModule = function PesquisaPageModule() {
      _classCallCheck(this, PesquisaPageModule);
    };

    PesquisaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _pesquisa_routing_module__WEBPACK_IMPORTED_MODULE_6__["PesquisaPageRoutingModule"]],
      declarations: [_components_tabs_tabs_component__WEBPACK_IMPORTED_MODULE_1__["TabsComponent"], _modal_resultado_pesquisa_resultado_pesquisa_page__WEBPACK_IMPORTED_MODULE_8__["ResultadoPesquisaPage"], _pesquisa_page__WEBPACK_IMPORTED_MODULE_7__["PesquisaPage"]],
      entryComponents: [_modal_resultado_pesquisa_resultado_pesquisa_page__WEBPACK_IMPORTED_MODULE_8__["ResultadoPesquisaPage"]]
    })], PesquisaPageModule);
    /***/
  },

  /***/
  "./src/app/pages/pesquisa/pesquisa.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/pages/pesquisa/pesquisa.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesPesquisaPesquisaPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --ion-background-color:#014677;\n}\n\n#formulario {\n  margin-top: 50px;\n  --ion-background-color:#FFF;\n  margin-left: 10px;\n  margin-right: 10px;\n  justify-content: center;\n}\n\n#titulo {\n  font-size: 25px;\n  color: #FFF;\n  text-align: center;\n  justify-content: center;\n  margin-top: 30px;\n}\n\n#btnPesquinsa {\n  margin-top: 25px;\n  margin-bottom: 25px;\n  width: -webkit-fill-available;\n  --background: #131313;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGVzcXVpc2EvQzpcXFVzZXJzXFxIdWRzb24ucmFtYWxob1xcRGVza3RvcFxcYW5kcmVcXG1ldXByb2R1dG8vc3JjXFxhcHBcXHBhZ2VzXFxwZXNxdWlzYVxccGVzcXVpc2EucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9wZXNxdWlzYS9wZXNxdWlzYS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSw4QkFBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7RUFDQSwyQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wZXNxdWlzYS9wZXNxdWlzYS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6IzAxNDY3NztcclxufVxyXG5cclxuI2Zvcm11bGFyaW97XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojRkZGO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuI3RpdHVsb3tcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIGNvbG9yOiAjRkZGO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG59XHJcblxyXG4jYnRuUGVzcXVpbnNhe1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDI1cHg7XHJcbiAgICB3aWR0aDogLXdlYmtpdC1maWxsLWF2YWlsYWJsZTtcclxuICAgIC0tYmFja2dyb3VuZDogIzEzMTMxMztcclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojMDE0Njc3O1xufVxuXG4jZm9ybXVsYXJpbyB7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6I0ZGRjtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbiN0aXR1bG8ge1xuICBmb250LXNpemU6IDI1cHg7XG4gIGNvbG9yOiAjRkZGO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAzMHB4O1xufVxuXG4jYnRuUGVzcXVpbnNhIHtcbiAgbWFyZ2luLXRvcDogMjVweDtcbiAgbWFyZ2luLWJvdHRvbTogMjVweDtcbiAgd2lkdGg6IC13ZWJraXQtZmlsbC1hdmFpbGFibGU7XG4gIC0tYmFja2dyb3VuZDogIzEzMTMxMztcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/pesquisa/pesquisa.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/pesquisa/pesquisa.page.ts ***!
    \*************************************************/

  /*! exports provided: PesquisaPage */

  /***/
  function srcAppPagesPesquisaPesquisaPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PesquisaPage", function () {
      return PesquisaPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/geolocation/ngx */
    "./node_modules/@ionic-native/geolocation/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _modal_resultado_pesquisa_resultado_pesquisa_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../modal/resultado-pesquisa/resultado-pesquisa.page */
    "./src/app/pages/modal/resultado-pesquisa/resultado-pesquisa.page.ts");

    var PesquisaPage = /*#__PURE__*/function () {
      function PesquisaPage(httpClient, geolocation, modalController) {
        _classCallCheck(this, PesquisaPage);

        this.httpClient = httpClient;
        this.geolocation = geolocation;
        this.modalController = modalController; // Latitude e Longitude

        this.latitude = 0;
        this.longitude = 0;
        this.options = {
          timeout: 10000,
          enableHighAccuracy: true,
          maximumAge: 3600
        }; // Usandos no request

        this.campo = '_embedded';
        this.baseUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].serveApi;
        this.httpOptions = {
          headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'application/json'
          })
        };
      }

      _createClass(PesquisaPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getCategoria();
          this.getMarca();
        }
        /*
        *  Recupera a localização geografica
        */

      }, {
        key: "getCurrentCoordinates",
        value: function getCurrentCoordinates() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.geolocation.getCurrentPosition().then(function (resp) {
                      _this.latitude = resp.coords.latitude;
                      _this.longitude = resp.coords.longitude;
                    })["catch"](function (error) {
                      console.log('Error getting location', error);
                    });

                  case 2:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
        /*
        * Recupera parametros para querystring
        */

      }, {
        key: "getParameter",
        value: function getParameter() {
          var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]();

          if (this.categoria.id != null) {
            params = params.append('idCategoria', this.categoria.id.toString());
          }

          if (this.marca.id != null) {
            params = params.append('idMarca', this.marca.id.toString());
          }

          if (this.produtoPesquisado != null) {
            params = params.append('nomeProduto', this.produtoPesquisado);
          }

          params = params.append('latitude', this.latitude);
          params = params.append('longitude', this.longitude);

          if (this.distancia != null) {
            params = params.append('distanceKM', this.distancia);
          }

          return params;
        }
        /*
         *  Realiza a pesquisa
         */

      }, {
        key: "pesquisar",
        value: function pesquisar() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this2 = this;

            var service, resource;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    this.resultadoPesquisa = '';
                    _context2.next = 3;
                    return this.getCurrentCoordinates();

                  case 3:
                    service = this.baseUrl + '/search';
                    resource = 'produtoSearchResponseResources';
                    this.httpClient.get(service, {
                      params: this.getParameter()
                    }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (data) {
                      return data[_this2.campo][resource];
                    })).subscribe(function (retorno) {
                      _this2.resultadoPesquisa = retorno;

                      _this2.openModal();
                    }, function (err) {
                      console.log(err);

                      _this2.openModal();
                    });

                  case 6:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
        /* ========================= */

        /* Recupera todas categorias */

        /* ========================= */

      }, {
        key: "getCategoria",
        value: function getCategoria() {
          var _this3 = this;

          var service = this.baseUrl + '/categorias';
          var resource = 'categoriaProdutoResources';
          this.httpClient.get(service).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (data) {
            return data[_this3.campo][resource];
          })).subscribe(function (categorias) {
            return _this3.categorias = categorias;
          });
        }
        /* ========================= */

        /* Recupera todas as marcas  */

        /* ========================= */

      }, {
        key: "getMarca",
        value: function getMarca() {
          var _this4 = this;

          var service = this.baseUrl + '/marcas';
          var resource = 'marcaProdutoResources';
          this.httpClient.get(service).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (data) {
            return data[_this4.campo][resource];
          })).subscribe(function (marcas) {
            return _this4.marcas = marcas;
          });
        }
      }, {
        key: "openModal",
        value: function openModal() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var modal;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.modalController.create({
                      component: _modal_resultado_pesquisa_resultado_pesquisa_page__WEBPACK_IMPORTED_MODULE_7__["ResultadoPesquisaPage"],
                      componentProps: {
                        resultadoPesquisa: this.resultadoPesquisa
                      }
                    });

                  case 2:
                    modal = _context3.sent;
                    _context3.next = 5;
                    return modal.present();

                  case 5:
                    return _context3.abrupt("return", _context3.sent);

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return PesquisaPage;
    }();

    PesquisaPage.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_4__["Geolocation"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
      }];
    };

    PesquisaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-pesquisa',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./pesquisa.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pesquisa/pesquisa.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./pesquisa.page.scss */
      "./src/app/pages/pesquisa/pesquisa.page.scss"))["default"]]
    })], PesquisaPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-pesquisa-pesquisa-module-es5.js.map
export const environment = {
  production: true,
  serveApi: 'http://meuproduto.ddns.net:8080/api'
};
